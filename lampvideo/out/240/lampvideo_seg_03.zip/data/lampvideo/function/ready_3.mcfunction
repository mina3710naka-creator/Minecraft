scoreboard players set #ready lv 3
