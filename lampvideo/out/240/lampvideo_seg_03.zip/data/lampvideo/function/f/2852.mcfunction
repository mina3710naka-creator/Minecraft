fill ~187 ~26 ~-1 ~187 ~26 ~-1 redstone_block
