fill ~116 ~80 ~-1 ~116 ~80 ~-1 black_concrete
fill ~116 ~80 ~ ~116 ~80 ~ redstone_lamp[lit=false]
fill ~115 ~80 ~-1 ~115 ~80 ~-1 redstone_block
