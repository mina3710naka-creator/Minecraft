fill ~235 ~59 ~-1 ~235 ~60 ~-1 black_concrete
fill ~235 ~59 ~ ~235 ~60 ~ redstone_lamp[lit=false]
fill ~230 ~55 ~-1 ~230 ~55 ~-1 black_concrete
fill ~230 ~55 ~ ~230 ~55 ~ redstone_lamp[lit=false]
fill ~189 ~37 ~-1 ~189 ~37 ~-1 black_concrete
fill ~189 ~37 ~ ~189 ~37 ~ redstone_lamp[lit=false]
fill ~230 ~62 ~-1 ~230 ~62 ~-1 redstone_block
fill ~234 ~50 ~-1 ~234 ~50 ~-1 redstone_block
