fill ~165 ~55 ~-1 ~165 ~55 ~-1 black_concrete
fill ~165 ~55 ~ ~165 ~55 ~ redstone_lamp[lit=false]
fill ~186 ~77 ~-1 ~186 ~77 ~-1 redstone_block
fill ~223 ~75 ~-1 ~223 ~75 ~-1 redstone_block
fill ~217 ~74 ~-1 ~217 ~74 ~-1 redstone_block
fill ~188 ~62 ~-1 ~188 ~62 ~-1 redstone_block
fill ~168 ~58 ~-1 ~168 ~58 ~-1 redstone_block
