fill ~235 ~89 ~-1 ~235 ~89 ~-1 redstone_block
fill ~168 ~81 ~-1 ~168 ~81 ~-1 redstone_block
fill ~170 ~65 ~-1 ~170 ~65 ~-1 redstone_block
