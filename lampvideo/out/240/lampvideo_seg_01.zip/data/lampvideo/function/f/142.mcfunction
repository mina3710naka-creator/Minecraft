fill ~148 ~122 ~-1 ~148 ~122 ~-1 redstone_block
fill ~101 ~91 ~-1 ~101 ~91 ~-1 redstone_block
