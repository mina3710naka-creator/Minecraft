fill ~125 ~167 ~-1 ~125 ~167 ~-1 black_concrete
fill ~125 ~167 ~ ~125 ~167 ~ redstone_lamp[lit=false]
fill ~96 ~160 ~-1 ~96 ~160 ~-1 black_concrete
fill ~96 ~160 ~ ~96 ~160 ~ redstone_lamp[lit=false]
fill ~148 ~119 ~-1 ~148 ~119 ~-1 black_concrete
fill ~148 ~119 ~ ~148 ~119 ~ redstone_lamp[lit=false]
fill ~149 ~118 ~-1 ~149 ~118 ~-1 redstone_block
