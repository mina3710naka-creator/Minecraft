fill ~226 ~77 ~-1 ~226 ~77 ~-1 black_concrete
fill ~226 ~77 ~ ~226 ~77 ~ redstone_lamp[lit=false]
fill ~232 ~72 ~-1 ~232 ~72 ~-1 black_concrete
fill ~232 ~72 ~ ~232 ~72 ~ redstone_lamp[lit=false]
fill ~162 ~71 ~-1 ~162 ~71 ~-1 redstone_block
fill ~161 ~69 ~-1 ~161 ~69 ~-1 redstone_block
fill ~159 ~64 ~-1 ~159 ~64 ~-1 redstone_block
