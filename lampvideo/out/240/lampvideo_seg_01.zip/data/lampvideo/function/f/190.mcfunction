fill ~0 ~0 ~-1 ~239 ~23 ~-1 black_concrete
fill ~0 ~0 ~ ~239 ~23 ~ redstone_lamp[lit=false]
