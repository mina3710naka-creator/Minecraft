fill ~0 ~104 ~-1 ~239 ~239 ~-1 black_concrete
fill ~0 ~104 ~ ~239 ~239 ~ redstone_lamp[lit=false]
fill ~0 ~0 ~-1 ~239 ~103 ~-1 black_concrete
fill ~0 ~0 ~ ~239 ~103 ~ redstone_lamp[lit=false]
