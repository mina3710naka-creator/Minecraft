fill ~231 ~91 ~-1 ~231 ~91 ~-1 black_concrete
fill ~231 ~91 ~ ~231 ~91 ~ redstone_lamp[lit=false]
fill ~220 ~69 ~-1 ~220 ~69 ~-1 redstone_block
fill ~161 ~69 ~-1 ~161 ~69 ~-1 redstone_block
fill ~159 ~59 ~-1 ~159 ~59 ~-1 redstone_block
