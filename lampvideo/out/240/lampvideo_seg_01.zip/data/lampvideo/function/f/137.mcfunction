fill ~146 ~145 ~-1 ~146 ~145 ~-1 black_concrete
fill ~146 ~145 ~ ~146 ~145 ~ redstone_lamp[lit=false]
fill ~103 ~108 ~-1 ~103 ~108 ~-1 black_concrete
fill ~103 ~108 ~ ~103 ~108 ~ redstone_lamp[lit=false]
fill ~112 ~136 ~-1 ~112 ~136 ~-1 redstone_block
fill ~103 ~117 ~-1 ~103 ~117 ~-1 redstone_block
fill ~138 ~111 ~-1 ~138 ~111 ~-1 redstone_block
