scoreboard players set #ready lv 1
