scoreboard players add #w lv 1
scoreboard players set #ready lv 0
function #lampvideo:ready
execute if score #ready lv = #want lv run function lampvideo:resume
execute unless score #ready lv = #want lv if score #w lv matches 240.. run function lampvideo:fail
execute unless score #ready lv = #want lv unless score #w lv matches 240.. run schedule function lampvideo:wait_on 5t
