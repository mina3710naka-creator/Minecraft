function lampvideo:release
schedule function lampvideo:wait_off 5t
