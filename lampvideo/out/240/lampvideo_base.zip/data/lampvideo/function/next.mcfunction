execute if score #d lv matches 4584.. run function lampvideo:stop
execute if score #run lv matches 1 if score #c lv matches 0 if score #d lv matches 1134 unless score #seg lv matches 2 run function lampvideo:switch
execute if score #run lv matches 1 if score #c lv matches 0 if score #d lv matches 2299 unless score #seg lv matches 3 run function lampvideo:switch
execute if score #run lv matches 1 if score #c lv matches 0 if score #d lv matches 2969 unless score #seg lv matches 4 run function lampvideo:switch
execute if score #run lv matches 1 if score #c lv matches 0 if score #d lv matches 4127 unless score #seg lv matches 5 run function lampvideo:switch
execute if score #run lv matches 1 if score #c lv matches 0 store result storage lampvideo:s n int 1 run scoreboard players get #d lv
execute if score #run lv matches 1 if score #c lv matches 0 run function lampvideo:step with storage lampvideo:s
execute if score #run lv matches 1 if score #c lv matches 0 run scoreboard players add #d lv 1
execute if score #run lv matches 1 run scoreboard players add #c lv 1
execute if score #run lv matches 1 if score #c lv matches 3.. run scoreboard players set #c lv 0
