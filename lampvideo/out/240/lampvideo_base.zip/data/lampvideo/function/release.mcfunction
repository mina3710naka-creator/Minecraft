scoreboard players set #ready lv 0
function #lampvideo:ready
execute if score #ready lv matches 1 run datapack disable "file/lampvideo_seg_01.zip"
execute if score #ready lv matches 2 run datapack disable "file/lampvideo_seg_02.zip"
execute if score #ready lv matches 3 run datapack disable "file/lampvideo_seg_03.zip"
execute if score #ready lv matches 4 run datapack disable "file/lampvideo_seg_04.zip"
execute if score #ready lv matches 5 run datapack disable "file/lampvideo_seg_05.zip"
