execute store result score #y lv run data get entity @s Pos[1]
execute if score #y lv matches 81.. run tellraw @s [{"text":"[ランプ動画] 高さ不足です。画面の高さが240ブロックあるので、Y=80以下の場所で実行してください(スーパーフラットの地面など)","color":"red"}]
execute if score #y lv matches 81.. run return 0
scoreboard players set #run lv 0
kill @e[type=marker,tag=lampvideo]
summon marker ~ ~ ~ {Tags:["lampvideo"]}
forceload add ~ ~-1 ~239 ~
schedule function lampvideo:draw 40t
tellraw @s [{"text":"[ランプ動画] 画面を準備中... 2秒後に設置します","color":"green"}]
