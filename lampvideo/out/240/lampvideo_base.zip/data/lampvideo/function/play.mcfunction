execute unless entity @e[type=marker,tag=lampvideo] run tellraw @s "先に /function lampvideo:setup を実行してください"
execute unless entity @e[type=marker,tag=lampvideo] run return 0
function lampvideo:stop
scoreboard players set #d lv 0
scoreboard players set #c lv 0
scoreboard players set #seg lv 0
scoreboard players set #want lv 1
scoreboard players set #run lv 2
function lampvideo:goto
