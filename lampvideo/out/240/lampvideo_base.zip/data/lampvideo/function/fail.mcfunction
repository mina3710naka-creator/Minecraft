function lampvideo:stop
tellraw @a [{"text":"[ランプ動画] 区間パックを読み込めませんでした。datapacks に lampvideo_seg_*.zip が全部あるか確認してください","color":"red"}]
