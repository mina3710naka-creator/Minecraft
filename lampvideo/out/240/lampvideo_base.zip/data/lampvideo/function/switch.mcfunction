scoreboard players set #run lv 2
scoreboard players operation #want lv = #seg lv
scoreboard players add #want lv 1
function lampvideo:goto
