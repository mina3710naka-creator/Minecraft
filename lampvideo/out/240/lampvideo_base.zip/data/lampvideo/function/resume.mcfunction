scoreboard players operation #seg lv = #want lv
scoreboard players set #run lv 1
execute if score #want lv matches 1 as @a at @s run playsound lampvideo:seg_01 master @s ~ ~ ~ 1 1
execute if score #want lv matches 2 as @a at @s run playsound lampvideo:seg_02 master @s ~ ~ ~ 1 1
execute if score #want lv matches 3 as @a at @s run playsound lampvideo:seg_03 master @s ~ ~ ~ 1 1
execute if score #want lv matches 4 as @a at @s run playsound lampvideo:seg_04 master @s ~ ~ ~ 1 1
execute if score #want lv matches 5 as @a at @s run playsound lampvideo:seg_05 master @s ~ ~ ~ 1 1
