scoreboard players set #w lv 0
scoreboard players set #ready lv 0
function #lampvideo:ready
execute if score #ready lv = #want lv run function lampvideo:resume
execute unless score #ready lv = #want lv if score #ready lv matches 1.. run function lampvideo:unload
execute unless score #ready lv = #want lv if score #ready lv matches 0 run function lampvideo:enable_next
