scoreboard players add #w lv 1
scoreboard players set #ready lv 0
function #lampvideo:ready
execute if score #ready lv matches 0 run function lampvideo:enable_next
execute unless score #ready lv matches 0 if score #w lv matches 240.. run function lampvideo:fail
execute unless score #ready lv matches 0 unless score #w lv matches 240.. run schedule function lampvideo:wait_off 5t
