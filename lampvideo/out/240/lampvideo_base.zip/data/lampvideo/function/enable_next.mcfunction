execute if score #want lv matches 1 run datapack enable "file/lampvideo_seg_01.zip"
execute if score #want lv matches 2 run datapack enable "file/lampvideo_seg_02.zip"
execute if score #want lv matches 3 run datapack enable "file/lampvideo_seg_03.zip"
execute if score #want lv matches 4 run datapack enable "file/lampvideo_seg_04.zip"
execute if score #want lv matches 5 run datapack enable "file/lampvideo_seg_05.zip"
schedule function lampvideo:wait_on 5t
