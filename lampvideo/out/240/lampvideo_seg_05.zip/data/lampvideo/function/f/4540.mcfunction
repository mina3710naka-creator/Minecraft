fill ~0 ~120 ~-1 ~239 ~143 ~-1 black_concrete
fill ~0 ~120 ~ ~239 ~143 ~ redstone_lamp[lit=false]
