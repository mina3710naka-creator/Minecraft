fill ~139 ~109 ~-1 ~139 ~109 ~-1 black_concrete
fill ~139 ~109 ~ ~139 ~109 ~ redstone_lamp[lit=false]
fill ~141 ~108 ~-1 ~141 ~108 ~-1 black_concrete
fill ~141 ~108 ~ ~141 ~108 ~ redstone_lamp[lit=false]
