fill ~0 ~145 ~-1 ~239 ~167 ~-1 black_concrete
fill ~0 ~145 ~ ~239 ~167 ~ redstone_lamp[lit=false]
fill ~0 ~144 ~-1 ~114 ~144 ~-1 black_concrete
fill ~0 ~144 ~ ~114 ~144 ~ redstone_lamp[lit=false]
fill ~124 ~144 ~-1 ~239 ~144 ~-1 black_concrete
fill ~124 ~144 ~ ~239 ~144 ~ redstone_lamp[lit=false]
fill ~115 ~144 ~-1 ~123 ~144 ~-1 redstone_block
