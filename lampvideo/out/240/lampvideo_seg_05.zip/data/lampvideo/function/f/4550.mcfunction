fill ~0 ~96 ~-1 ~239 ~119 ~-1 black_concrete
fill ~0 ~96 ~ ~239 ~119 ~ redstone_lamp[lit=false]
