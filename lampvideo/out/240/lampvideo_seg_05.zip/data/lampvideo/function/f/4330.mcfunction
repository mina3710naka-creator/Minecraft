fill ~0 ~144 ~-1 ~239 ~167 ~-1 black_concrete
fill ~0 ~144 ~ ~239 ~167 ~ redstone_lamp[lit=false]
