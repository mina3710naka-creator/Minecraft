scoreboard players set #ready lv 4
