fill ~103 ~90 ~-1 ~103 ~90 ~-1 black_concrete
fill ~103 ~90 ~ ~103 ~90 ~ redstone_lamp[lit=false]
fill ~204 ~227 ~-1 ~204 ~227 ~-1 redstone_block
fill ~102 ~51 ~-1 ~102 ~51 ~-1 redstone_block
