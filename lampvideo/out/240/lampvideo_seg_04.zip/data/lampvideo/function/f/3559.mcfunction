fill ~209 ~81 ~-1 ~209 ~81 ~-1 black_concrete
fill ~209 ~81 ~ ~209 ~81 ~ redstone_lamp[lit=false]
fill ~2 ~0 ~-1 ~2 ~0 ~-1 black_concrete
fill ~2 ~0 ~ ~2 ~0 ~ redstone_lamp[lit=false]
