fill ~213 ~78 ~-1 ~213 ~78 ~-1 black_concrete
fill ~213 ~78 ~ ~213 ~78 ~ redstone_lamp[lit=false]
fill ~177 ~132 ~-1 ~177 ~132 ~-1 redstone_block
fill ~99 ~77 ~-1 ~99 ~77 ~-1 redstone_block
fill ~102 ~73 ~-1 ~102 ~73 ~-1 redstone_block
fill ~97 ~55 ~-1 ~97 ~55 ~-1 redstone_block
