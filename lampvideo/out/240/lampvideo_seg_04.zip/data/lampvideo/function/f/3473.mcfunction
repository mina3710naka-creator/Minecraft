fill ~199 ~134 ~-1 ~199 ~134 ~-1 black_concrete
fill ~199 ~134 ~ ~199 ~134 ~ redstone_lamp[lit=false]
fill ~170 ~110 ~-1 ~170 ~111 ~-1 black_concrete
fill ~170 ~110 ~ ~170 ~111 ~ redstone_lamp[lit=false]
fill ~108 ~63 ~-1 ~108 ~63 ~-1 black_concrete
fill ~108 ~63 ~ ~108 ~63 ~ redstone_lamp[lit=false]
fill ~118 ~42 ~-1 ~118 ~42 ~-1 redstone_block
