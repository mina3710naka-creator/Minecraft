fill ~124 ~52 ~-1 ~124 ~52 ~-1 black_concrete
fill ~124 ~52 ~ ~124 ~52 ~ redstone_lamp[lit=false]
fill ~138 ~205 ~-1 ~138 ~205 ~-1 redstone_block
fill ~112 ~42 ~-1 ~112 ~42 ~-1 redstone_block
