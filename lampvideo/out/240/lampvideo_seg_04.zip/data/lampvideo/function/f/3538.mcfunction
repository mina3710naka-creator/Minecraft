fill ~103 ~53 ~-1 ~103 ~53 ~-1 black_concrete
fill ~103 ~53 ~ ~103 ~53 ~ redstone_lamp[lit=false]
fill ~112 ~83 ~-1 ~112 ~83 ~-1 redstone_block
fill ~101 ~58 ~-1 ~101 ~58 ~-1 redstone_block
fill ~98 ~57 ~-1 ~98 ~57 ~-1 redstone_block
