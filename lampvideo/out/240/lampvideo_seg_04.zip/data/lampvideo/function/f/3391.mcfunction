fill ~138 ~205 ~-1 ~138 ~205 ~-1 black_concrete
fill ~138 ~205 ~ ~138 ~205 ~ redstone_lamp[lit=false]
fill ~131 ~127 ~-1 ~131 ~127 ~-1 black_concrete
fill ~131 ~127 ~ ~131 ~127 ~ redstone_lamp[lit=false]
fill ~112 ~105 ~-1 ~112 ~105 ~-1 black_concrete
fill ~112 ~105 ~ ~112 ~105 ~ redstone_lamp[lit=false]
fill ~119 ~50 ~-1 ~119 ~50 ~-1 black_concrete
fill ~119 ~50 ~ ~119 ~50 ~ redstone_lamp[lit=false]
