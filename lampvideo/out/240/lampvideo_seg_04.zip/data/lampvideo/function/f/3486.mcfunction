fill ~212 ~78 ~-1 ~212 ~78 ~-1 black_concrete
fill ~212 ~78 ~ ~212 ~78 ~ redstone_lamp[lit=false]
