fill ~0 ~0 ~-1 ~239 ~23 ~-1 redstone_block
