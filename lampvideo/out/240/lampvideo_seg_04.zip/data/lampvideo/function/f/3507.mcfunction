fill ~99 ~61 ~-1 ~99 ~61 ~-1 black_concrete
fill ~99 ~61 ~ ~99 ~61 ~ redstone_lamp[lit=false]
fill ~113 ~54 ~-1 ~113 ~54 ~-1 black_concrete
fill ~113 ~54 ~ ~113 ~54 ~ redstone_lamp[lit=false]
fill ~200 ~218 ~-1 ~200 ~218 ~-1 redstone_block
fill ~97 ~56 ~-1 ~97 ~56 ~-1 redstone_block
