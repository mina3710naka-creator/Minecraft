fill ~115 ~53 ~-1 ~115 ~53 ~-1 black_concrete
fill ~115 ~53 ~ ~115 ~53 ~ redstone_lamp[lit=false]
