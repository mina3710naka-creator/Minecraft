fill ~123 ~53 ~-1 ~123 ~53 ~-1 black_concrete
fill ~123 ~53 ~ ~123 ~53 ~ redstone_lamp[lit=false]
fill ~58 ~219 ~-1 ~58 ~219 ~-1 redstone_block
fill ~220 ~76 ~-1 ~220 ~76 ~-1 redstone_block
fill ~43 ~73 ~-1 ~43 ~73 ~-1 redstone_block
