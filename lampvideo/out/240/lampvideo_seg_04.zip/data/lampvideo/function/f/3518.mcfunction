fill ~59 ~205 ~-1 ~59 ~205 ~-1 black_concrete
fill ~59 ~205 ~ ~59 ~205 ~ redstone_lamp[lit=false]
