fill ~204 ~219 ~-1 ~204 ~219 ~-1 black_concrete
fill ~204 ~219 ~ ~204 ~219 ~ redstone_lamp[lit=false]
fill ~110 ~50 ~-1 ~110 ~50 ~-1 black_concrete
fill ~110 ~50 ~ ~110 ~50 ~ redstone_lamp[lit=false]
fill ~114 ~48 ~-1 ~114 ~48 ~-1 black_concrete
fill ~114 ~48 ~ ~114 ~48 ~ redstone_lamp[lit=false]
fill ~103 ~116 ~-1 ~103 ~116 ~-1 redstone_block
fill ~97 ~61 ~-1 ~97 ~61 ~-1 redstone_block
