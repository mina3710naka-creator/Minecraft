fill ~104 ~68 ~-1 ~104 ~68 ~-1 black_concrete
fill ~104 ~68 ~ ~104 ~68 ~ redstone_lamp[lit=false]
fill ~115 ~46 ~-1 ~115 ~46 ~-1 black_concrete
fill ~115 ~46 ~ ~115 ~46 ~ redstone_lamp[lit=false]
fill ~95 ~50 ~-1 ~95 ~50 ~-1 redstone_block
fill ~110 ~48 ~-1 ~110 ~48 ~-1 redstone_block
fill ~113 ~45 ~-1 ~113 ~45 ~-1 redstone_block
fill ~118 ~41 ~-1 ~118 ~41 ~-1 redstone_block
