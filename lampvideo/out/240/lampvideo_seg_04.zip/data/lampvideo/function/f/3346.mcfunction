fill ~200 ~220 ~-1 ~200 ~220 ~-1 black_concrete
fill ~200 ~220 ~ ~200 ~220 ~ redstone_lamp[lit=false]
fill ~220 ~78 ~-1 ~220 ~78 ~-1 black_concrete
fill ~220 ~78 ~ ~220 ~78 ~ redstone_lamp[lit=false]
fill ~119 ~48 ~-1 ~119 ~48 ~-1 black_concrete
fill ~119 ~48 ~ ~119 ~48 ~ redstone_lamp[lit=false]
fill ~104 ~66 ~-1 ~104 ~66 ~-1 redstone_block
