fill ~0 ~96 ~-1 ~239 ~119 ~-1 redstone_block
