fill ~0 ~192 ~-1 ~239 ~215 ~-1 redstone_block
