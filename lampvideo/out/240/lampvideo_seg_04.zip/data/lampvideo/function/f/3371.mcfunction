fill ~217 ~78 ~-1 ~217 ~78 ~-1 black_concrete
fill ~217 ~78 ~ ~217 ~78 ~ redstone_lamp[lit=false]
fill ~110 ~116 ~-1 ~110 ~116 ~-1 redstone_block
fill ~98 ~75 ~-1 ~98 ~75 ~-1 redstone_block
fill ~106 ~50 ~-1 ~106 ~50 ~-1 redstone_block
