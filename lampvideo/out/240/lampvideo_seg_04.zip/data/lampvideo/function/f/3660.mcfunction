fill ~0 ~72 ~-1 ~239 ~95 ~-1 redstone_block
