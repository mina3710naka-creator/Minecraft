fill ~182 ~215 ~-1 ~182 ~215 ~-1 black_concrete
fill ~182 ~215 ~ ~182 ~215 ~ redstone_lamp[lit=false]
fill ~175 ~131 ~-1 ~175 ~131 ~-1 redstone_block
fill ~103 ~44 ~-1 ~103 ~44 ~-1 redstone_block
