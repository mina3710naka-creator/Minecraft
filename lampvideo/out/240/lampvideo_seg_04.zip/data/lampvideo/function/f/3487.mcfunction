fill ~59 ~218 ~-1 ~59 ~218 ~-1 black_concrete
fill ~59 ~218 ~ ~59 ~218 ~ redstone_lamp[lit=false]
fill ~111 ~56 ~-1 ~111 ~56 ~-1 black_concrete
fill ~111 ~56 ~ ~111 ~56 ~ redstone_lamp[lit=false]
