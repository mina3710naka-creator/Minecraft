fill ~107 ~76 ~-1 ~107 ~76 ~-1 black_concrete
fill ~107 ~76 ~ ~107 ~76 ~ redstone_lamp[lit=false]
fill ~122 ~51 ~-1 ~122 ~51 ~-1 black_concrete
fill ~122 ~51 ~ ~122 ~51 ~ redstone_lamp[lit=false]
fill ~117 ~50 ~-1 ~117 ~50 ~-1 black_concrete
fill ~117 ~50 ~ ~117 ~50 ~ redstone_lamp[lit=false]
fill ~124 ~47 ~-1 ~124 ~47 ~-1 redstone_block
