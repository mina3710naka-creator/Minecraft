fill ~113 ~55 ~-1 ~113 ~55 ~-1 black_concrete
fill ~113 ~55 ~ ~113 ~55 ~ redstone_lamp[lit=false]
