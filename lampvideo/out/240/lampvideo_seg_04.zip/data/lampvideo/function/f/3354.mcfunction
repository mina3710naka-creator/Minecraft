fill ~118 ~48 ~-1 ~118 ~48 ~-1 black_concrete
fill ~118 ~48 ~ ~118 ~48 ~ redstone_lamp[lit=false]
fill ~104 ~48 ~-1 ~104 ~48 ~-1 redstone_block
