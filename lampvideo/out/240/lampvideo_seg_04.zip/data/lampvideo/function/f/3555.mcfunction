fill ~104 ~69 ~-1 ~104 ~69 ~-1 black_concrete
fill ~104 ~69 ~ ~104 ~69 ~ redstone_lamp[lit=false]
fill ~104 ~65 ~-1 ~104 ~65 ~-1 redstone_block
fill ~102 ~64 ~-1 ~102 ~64 ~-1 redstone_block
fill ~112 ~44 ~-1 ~112 ~44 ~-1 redstone_block
