fill ~101 ~60 ~-1 ~101 ~60 ~-1 black_concrete
fill ~101 ~60 ~ ~101 ~60 ~ redstone_lamp[lit=false]
fill ~105 ~53 ~-1 ~105 ~53 ~-1 redstone_block
