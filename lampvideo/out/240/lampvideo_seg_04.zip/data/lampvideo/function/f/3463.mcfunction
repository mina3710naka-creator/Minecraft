fill ~103 ~57 ~-1 ~103 ~57 ~-1 black_concrete
fill ~103 ~57 ~ ~103 ~57 ~ redstone_lamp[lit=false]
fill ~137 ~227 ~-1 ~137 ~227 ~-1 redstone_block
fill ~203 ~218 ~-1 ~203 ~218 ~-1 redstone_block
fill ~103 ~53 ~-1 ~103 ~53 ~-1 redstone_block
