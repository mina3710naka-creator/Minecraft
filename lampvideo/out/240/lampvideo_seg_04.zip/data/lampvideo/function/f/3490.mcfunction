fill ~140 ~212 ~-1 ~140 ~212 ~-1 black_concrete
fill ~140 ~212 ~ ~140 ~212 ~ redstone_lamp[lit=false]
fill ~110 ~51 ~-1 ~110 ~51 ~-1 black_concrete
fill ~110 ~51 ~ ~110 ~51 ~ redstone_lamp[lit=false]
fill ~181 ~219 ~-1 ~181 ~219 ~-1 redstone_block
fill ~0 ~0 ~-1 ~239 ~23 ~-1 redstone_block
