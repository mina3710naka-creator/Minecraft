fill ~107 ~64 ~-1 ~107 ~64 ~-1 black_concrete
fill ~107 ~64 ~ ~107 ~64 ~ redstone_lamp[lit=false]
fill ~109 ~62 ~-1 ~109 ~62 ~-1 black_concrete
fill ~109 ~62 ~ ~109 ~62 ~ redstone_lamp[lit=false]
fill ~110 ~100 ~-1 ~110 ~100 ~-1 redstone_block
