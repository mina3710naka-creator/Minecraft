fill ~123 ~129 ~-1 ~123 ~129 ~-1 black_concrete
fill ~123 ~129 ~ ~123 ~129 ~ redstone_lamp[lit=false]
