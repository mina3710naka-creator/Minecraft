fill ~136 ~140 ~-1 ~136 ~140 ~-1 black_concrete
fill ~136 ~140 ~ ~136 ~140 ~ redstone_lamp[lit=false]
fill ~224 ~88 ~-1 ~224 ~88 ~-1 black_concrete
fill ~224 ~88 ~ ~224 ~88 ~ redstone_lamp[lit=false]
fill ~230 ~74 ~-1 ~230 ~74 ~-1 redstone_block
