fill ~234 ~83 ~-1 ~234 ~83 ~-1 black_concrete
fill ~234 ~83 ~ ~234 ~83 ~ redstone_lamp[lit=false]
fill ~195 ~87 ~-1 ~195 ~87 ~-1 redstone_block
