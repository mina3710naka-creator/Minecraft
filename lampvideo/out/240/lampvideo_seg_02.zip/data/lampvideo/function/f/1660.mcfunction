fill ~0 ~72 ~-1 ~239 ~95 ~-1 black_concrete
fill ~0 ~72 ~ ~239 ~95 ~ redstone_lamp[lit=false]
