fill ~169 ~120 ~-1 ~169 ~120 ~-1 black_concrete
fill ~169 ~120 ~ ~169 ~120 ~ redstone_lamp[lit=false]
fill ~172 ~96 ~-1 ~172 ~96 ~-1 redstone_block
