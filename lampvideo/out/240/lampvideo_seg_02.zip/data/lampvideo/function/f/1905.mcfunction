fill ~231 ~89 ~-1 ~231 ~89 ~-1 black_concrete
fill ~231 ~89 ~ ~231 ~89 ~ redstone_lamp[lit=false]
fill ~235 ~83 ~-1 ~235 ~83 ~-1 black_concrete
fill ~235 ~83 ~ ~235 ~83 ~ redstone_lamp[lit=false]
