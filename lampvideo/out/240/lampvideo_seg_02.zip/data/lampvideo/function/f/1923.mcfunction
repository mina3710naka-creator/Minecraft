fill ~184 ~60 ~-1 ~184 ~60 ~-1 redstone_block
