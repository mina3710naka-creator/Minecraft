fill ~0 ~216 ~-1 ~239 ~239 ~-1 black_concrete
fill ~0 ~216 ~ ~239 ~239 ~ redstone_lamp[lit=false]
