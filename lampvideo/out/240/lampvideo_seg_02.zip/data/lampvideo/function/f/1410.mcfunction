fill ~0 ~192 ~-1 ~239 ~215 ~-1 black_concrete
fill ~0 ~192 ~ ~239 ~215 ~ redstone_lamp[lit=false]
fill ~220 ~66 ~-1 ~220 ~66 ~-1 redstone_block
fill ~217 ~64 ~-1 ~217 ~64 ~-1 redstone_block
fill ~213 ~60 ~-1 ~213 ~60 ~-1 redstone_block
fill ~205 ~56 ~-1 ~205 ~56 ~-1 redstone_block
fill ~40 ~27 ~-1 ~40 ~27 ~-1 redstone_block
