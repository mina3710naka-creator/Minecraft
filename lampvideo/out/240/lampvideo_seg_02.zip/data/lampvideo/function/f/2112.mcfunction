fill ~175 ~81 ~-1 ~175 ~81 ~-1 black_concrete
fill ~175 ~81 ~ ~175 ~81 ~ redstone_lamp[lit=false]
