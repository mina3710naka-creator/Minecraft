fill ~225 ~107 ~-1 ~225 ~107 ~-1 redstone_block
fill ~176 ~101 ~-1 ~176 ~101 ~-1 redstone_block
fill ~157 ~87 ~-1 ~157 ~87 ~-1 redstone_block
