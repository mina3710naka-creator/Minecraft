fill ~197 ~87 ~-1 ~197 ~87 ~-1 black_concrete
fill ~197 ~87 ~ ~197 ~87 ~ redstone_lamp[lit=false]
fill ~236 ~57 ~-1 ~236 ~57 ~-1 black_concrete
fill ~236 ~57 ~ ~236 ~57 ~ redstone_lamp[lit=false]
fill ~170 ~94 ~-1 ~170 ~94 ~-1 redstone_block
fill ~201 ~90 ~-1 ~201 ~90 ~-1 redstone_block
fill ~169 ~86 ~-1 ~169 ~86 ~-1 redstone_block
fill ~173 ~81 ~-1 ~173 ~81 ~-1 redstone_block
