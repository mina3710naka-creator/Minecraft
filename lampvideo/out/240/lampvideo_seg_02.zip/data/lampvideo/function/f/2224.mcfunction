fill ~220 ~105 ~-1 ~220 ~105 ~-1 redstone_block
