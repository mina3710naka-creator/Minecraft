fill ~182 ~89 ~-1 ~182 ~89 ~-1 black_concrete
fill ~182 ~89 ~ ~182 ~89 ~ redstone_lamp[lit=false]
fill ~186 ~87 ~-1 ~186 ~87 ~-1 black_concrete
fill ~186 ~87 ~ ~186 ~87 ~ redstone_lamp[lit=false]
fill ~188 ~86 ~-1 ~189 ~86 ~-1 black_concrete
fill ~188 ~86 ~ ~189 ~86 ~ redstone_lamp[lit=false]
fill ~197 ~115 ~-1 ~197 ~115 ~-1 redstone_block
fill ~190 ~88 ~-1 ~190 ~88 ~-1 redstone_block
