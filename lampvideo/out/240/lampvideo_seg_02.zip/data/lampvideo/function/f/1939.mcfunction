fill ~203 ~99 ~-1 ~203 ~99 ~-1 black_concrete
fill ~203 ~99 ~ ~203 ~99 ~ redstone_lamp[lit=false]
fill ~230 ~74 ~-1 ~230 ~74 ~-1 black_concrete
fill ~230 ~74 ~ ~230 ~74 ~ redstone_lamp[lit=false]
fill ~226 ~76 ~-1 ~226 ~76 ~-1 redstone_block
