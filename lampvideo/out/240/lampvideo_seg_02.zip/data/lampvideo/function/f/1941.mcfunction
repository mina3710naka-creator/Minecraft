fill ~228 ~88 ~-1 ~228 ~88 ~-1 black_concrete
fill ~228 ~88 ~ ~228 ~88 ~ redstone_lamp[lit=false]
fill ~232 ~73 ~-1 ~232 ~73 ~-1 black_concrete
fill ~232 ~73 ~ ~232 ~73 ~ redstone_lamp[lit=false]
