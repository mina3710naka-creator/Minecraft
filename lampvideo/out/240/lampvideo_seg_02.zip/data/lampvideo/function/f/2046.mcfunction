fill ~154 ~91 ~-1 ~154 ~91 ~-1 black_concrete
fill ~154 ~91 ~ ~154 ~91 ~ redstone_lamp[lit=false]
