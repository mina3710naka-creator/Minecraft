fill ~219 ~90 ~-1 ~219 ~90 ~-1 black_concrete
fill ~219 ~90 ~ ~219 ~90 ~ redstone_lamp[lit=false]
