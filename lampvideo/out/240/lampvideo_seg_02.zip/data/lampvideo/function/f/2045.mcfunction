fill ~226 ~82 ~-1 ~226 ~82 ~-1 black_concrete
fill ~226 ~82 ~ ~226 ~82 ~ redstone_lamp[lit=false]
fill ~215 ~86 ~-1 ~215 ~86 ~-1 redstone_block
fill ~157 ~76 ~-1 ~157 ~76 ~-1 redstone_block
