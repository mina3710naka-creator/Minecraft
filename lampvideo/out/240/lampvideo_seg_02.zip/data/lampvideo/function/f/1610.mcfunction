fill ~0 ~192 ~-1 ~239 ~215 ~-1 black_concrete
fill ~0 ~192 ~ ~239 ~215 ~ redstone_lamp[lit=false]
