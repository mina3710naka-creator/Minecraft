fill ~158 ~96 ~-1 ~158 ~96 ~-1 black_concrete
fill ~158 ~96 ~ ~158 ~96 ~ redstone_lamp[lit=false]
fill ~154 ~91 ~-1 ~154 ~91 ~-1 black_concrete
fill ~154 ~91 ~ ~154 ~91 ~ redstone_lamp[lit=false]
fill ~156 ~92 ~-1 ~156 ~92 ~-1 redstone_block
fill ~178 ~83 ~-1 ~178 ~83 ~-1 redstone_block
