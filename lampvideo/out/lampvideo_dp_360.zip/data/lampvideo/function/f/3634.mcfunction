fill ~177 ~225 ~-1 ~177 ~225 ~-1 redstone_block
fill ~177 ~223 ~-1 ~177 ~223 ~-1 redstone_block
fill ~144 ~126 ~-1 ~144 ~126 ~-1 black_concrete
