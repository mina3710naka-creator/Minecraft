fill ~119 ~68 ~-1 ~119 ~68 ~-1 redstone_block
fill ~268 ~199 ~-1 ~268 ~199 ~-1 black_concrete
