fill ~144 ~66 ~-1 ~144 ~66 ~-1 redstone_block
