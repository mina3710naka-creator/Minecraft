fill ~304 ~49 ~-1 ~304 ~49 ~-1 redstone_block
