fill ~205 ~120 ~-1 ~205 ~120 ~-1 redstone_block
fill ~207 ~115 ~-1 ~207 ~115 ~-1 redstone_block
fill ~164 ~163 ~-1 ~164 ~163 ~-1 black_concrete
fill ~175 ~153 ~-1 ~175 ~153 ~-1 black_concrete
fill ~205 ~121 ~-1 ~205 ~133 ~-1 black_concrete
