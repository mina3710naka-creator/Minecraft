fill ~72 ~23 ~-1 ~72 ~23 ~-1 black_concrete
