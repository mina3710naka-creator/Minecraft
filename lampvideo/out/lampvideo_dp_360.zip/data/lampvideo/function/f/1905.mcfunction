fill ~349 ~125 ~-1 ~349 ~125 ~-1 redstone_block
fill ~343 ~121 ~-1 ~343 ~121 ~-1 redstone_block
fill ~338 ~167 ~-1 ~338 ~167 ~-1 black_concrete
fill ~307 ~109 ~-1 ~307 ~109 ~-1 black_concrete
fill ~257 ~84 ~-1 ~257 ~84 ~-1 black_concrete
