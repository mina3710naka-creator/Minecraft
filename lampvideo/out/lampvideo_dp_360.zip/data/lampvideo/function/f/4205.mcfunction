fill ~208 ~163 ~-1 ~208 ~163 ~-1 redstone_block
fill ~212 ~162 ~-1 ~212 ~162 ~-1 redstone_block
