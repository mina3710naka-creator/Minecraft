fill ~207 ~179 ~-1 ~207 ~179 ~-1 redstone_block
fill ~227 ~132 ~-1 ~227 ~132 ~-1 redstone_block
