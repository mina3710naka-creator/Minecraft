fill ~47 ~23 ~-1 ~47 ~23 ~-1 redstone_block
fill ~264 ~176 ~-1 ~264 ~176 ~-1 black_concrete
