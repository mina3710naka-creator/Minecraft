fill ~264 ~176 ~-1 ~264 ~176 ~-1 black_concrete
fill ~158 ~166 ~-1 ~158 ~166 ~-1 black_concrete
fill ~159 ~164 ~-1 ~159 ~164 ~-1 black_concrete
