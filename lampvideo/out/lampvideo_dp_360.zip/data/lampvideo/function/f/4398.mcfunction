fill ~162 ~90 ~-1 ~162 ~90 ~-1 black_concrete
