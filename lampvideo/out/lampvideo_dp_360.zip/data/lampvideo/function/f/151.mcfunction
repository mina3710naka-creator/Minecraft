fill ~141 ~223 ~-1 ~141 ~223 ~-1 redstone_block
fill ~139 ~195 ~-1 ~139 ~195 ~-1 redstone_block
fill ~221 ~194 ~-1 ~221 ~194 ~-1 redstone_block
fill ~197 ~200 ~-1 ~197 ~200 ~-1 black_concrete
fill ~220 ~192 ~-1 ~220 ~192 ~-1 black_concrete
