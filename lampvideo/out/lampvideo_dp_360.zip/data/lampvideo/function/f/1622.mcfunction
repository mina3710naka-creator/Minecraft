fill ~145 ~273 ~-1 ~145 ~273 ~-1 black_concrete
