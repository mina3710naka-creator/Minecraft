fill ~206 ~224 ~-1 ~206 ~224 ~-1 redstone_block
fill ~108 ~134 ~-1 ~108 ~134 ~-1 redstone_block
fill ~224 ~104 ~-1 ~224 ~104 ~-1 redstone_block
fill ~223 ~104 ~-1 ~223 ~104 ~-1 black_concrete
