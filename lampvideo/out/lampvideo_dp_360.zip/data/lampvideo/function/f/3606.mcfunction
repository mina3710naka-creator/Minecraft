fill ~27 ~160 ~-1 ~27 ~167 ~-1 black_concrete
fill ~28 ~152 ~-1 ~28 ~159 ~-1 black_concrete
