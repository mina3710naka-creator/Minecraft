fill ~259 ~172 ~-1 ~259 ~172 ~-1 redstone_block
fill ~359 ~84 ~-1 ~359 ~84 ~-1 black_concrete
fill ~269 ~81 ~-1 ~269 ~81 ~-1 black_concrete
