fill ~352 ~84 ~-1 ~352 ~84 ~-1 black_concrete
fill ~268 ~82 ~-1 ~268 ~82 ~-1 black_concrete
