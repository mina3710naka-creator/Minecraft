fill ~ ~0 ~-1 ~359 ~29 ~1 air
fill ~ ~30 ~-1 ~359 ~59 ~1 air
fill ~ ~60 ~-1 ~359 ~89 ~1 air
fill ~ ~90 ~-1 ~359 ~119 ~1 air
fill ~ ~120 ~-1 ~359 ~149 ~1 air
fill ~ ~150 ~-1 ~359 ~179 ~1 air
fill ~ ~180 ~-1 ~359 ~209 ~1 air
fill ~ ~210 ~-1 ~359 ~239 ~1 air
fill ~ ~240 ~-1 ~359 ~269 ~1 air
fill ~ ~270 ~-1 ~359 ~299 ~1 air
fill ~ ~300 ~-1 ~359 ~329 ~1 air
fill ~ ~330 ~-1 ~359 ~359 ~1 air
forceload remove ~ ~-1 ~359 ~
