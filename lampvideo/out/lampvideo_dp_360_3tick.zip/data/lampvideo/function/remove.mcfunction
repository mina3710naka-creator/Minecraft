scoreboard players set #run lv 0
execute as @e[type=marker,tag=lampvideo,limit=1] at @s run function lampvideo:remove_do
kill @e[type=marker,tag=lampvideo]
