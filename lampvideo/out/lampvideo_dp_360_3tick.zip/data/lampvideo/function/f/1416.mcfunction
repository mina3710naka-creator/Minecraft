fill ~264 ~176 ~-1 ~264 ~176 ~-1 redstone_block
fill ~158 ~166 ~-1 ~158 ~166 ~-1 redstone_block
fill ~159 ~164 ~-1 ~159 ~164 ~-1 redstone_block
