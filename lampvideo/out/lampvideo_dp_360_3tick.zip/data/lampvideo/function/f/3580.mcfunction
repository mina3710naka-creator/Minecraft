fill ~207 ~179 ~-1 ~207 ~179 ~-1 black_concrete
fill ~207 ~179 ~ ~207 ~179 ~ redstone_lamp[lit=false]
fill ~227 ~132 ~-1 ~227 ~132 ~-1 black_concrete
fill ~227 ~132 ~ ~227 ~132 ~ redstone_lamp[lit=false]
fill ~0 ~36 ~-1 ~359 ~71 ~-1 redstone_block
