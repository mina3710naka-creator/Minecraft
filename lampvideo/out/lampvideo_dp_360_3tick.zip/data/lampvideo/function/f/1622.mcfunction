fill ~145 ~273 ~-1 ~145 ~273 ~-1 redstone_block
