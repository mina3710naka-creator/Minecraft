fill ~349 ~125 ~-1 ~349 ~125 ~-1 black_concrete
fill ~349 ~125 ~ ~349 ~125 ~ redstone_lamp[lit=false]
fill ~343 ~121 ~-1 ~343 ~121 ~-1 black_concrete
fill ~343 ~121 ~ ~343 ~121 ~ redstone_lamp[lit=false]
fill ~338 ~167 ~-1 ~338 ~167 ~-1 redstone_block
fill ~307 ~109 ~-1 ~307 ~109 ~-1 redstone_block
fill ~257 ~84 ~-1 ~257 ~84 ~-1 redstone_block
