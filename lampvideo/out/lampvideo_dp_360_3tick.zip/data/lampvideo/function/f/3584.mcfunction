fill ~334 ~200 ~-1 ~334 ~200 ~-1 redstone_block
fill ~152 ~133 ~-1 ~152 ~133 ~-1 redstone_block
