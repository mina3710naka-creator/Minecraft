fill ~119 ~68 ~-1 ~119 ~68 ~-1 black_concrete
fill ~119 ~68 ~ ~119 ~68 ~ redstone_lamp[lit=false]
fill ~268 ~199 ~-1 ~268 ~199 ~-1 redstone_block
