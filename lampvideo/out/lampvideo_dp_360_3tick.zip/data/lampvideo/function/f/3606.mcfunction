fill ~27 ~160 ~-1 ~27 ~167 ~-1 redstone_block
fill ~28 ~152 ~-1 ~28 ~159 ~-1 redstone_block
