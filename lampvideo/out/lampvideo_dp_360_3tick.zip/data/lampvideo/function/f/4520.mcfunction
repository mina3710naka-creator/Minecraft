fill ~0 ~252 ~-1 ~359 ~287 ~-1 black_concrete
fill ~0 ~252 ~ ~359 ~287 ~ redstone_lamp[lit=false]
