fill ~208 ~163 ~-1 ~208 ~163 ~-1 black_concrete
fill ~208 ~163 ~ ~208 ~163 ~ redstone_lamp[lit=false]
fill ~212 ~162 ~-1 ~212 ~162 ~-1 black_concrete
fill ~212 ~162 ~ ~212 ~162 ~ redstone_lamp[lit=false]
