fill ~0 ~324 ~-1 ~359 ~359 ~-1 redstone_block
