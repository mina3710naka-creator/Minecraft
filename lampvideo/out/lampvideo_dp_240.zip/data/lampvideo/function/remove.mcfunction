scoreboard players set #run lv 0
execute as @e[type=marker,tag=lampvideo,limit=1] at @s run forceload remove ~ ~-1 ~239 ~
kill @e[type=marker,tag=lampvideo]
