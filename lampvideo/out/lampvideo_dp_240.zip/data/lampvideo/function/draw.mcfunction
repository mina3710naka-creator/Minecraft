execute as @e[type=marker,tag=lampvideo,limit=1] at @s run function lampvideo:draw_do
tellraw @a [{"text":"[ランプ動画] 画面を設置しました。南側から北を向いて見てください。/function lampvideo:play で再生","color":"green"}]
