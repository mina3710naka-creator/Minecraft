fill ~234 ~83 ~-1 ~234 ~83 ~-1 redstone_block
fill ~195 ~87 ~-1 ~195 ~87 ~-1 black_concrete
