fill ~120 ~54 ~-1 ~120 ~54 ~-1 redstone_block
fill ~104 ~52 ~-1 ~104 ~52 ~-1 redstone_block
fill ~59 ~219 ~-1 ~59 ~219 ~-1 black_concrete
