fill ~119 ~51 ~-1 ~119 ~51 ~-1 redstone_block
fill ~184 ~216 ~-1 ~184 ~216 ~-1 black_concrete
fill ~225 ~74 ~-1 ~225 ~74 ~-1 black_concrete
fill ~116 ~40 ~-1 ~116 ~40 ~-1 black_concrete
fill ~119 ~40 ~-1 ~119 ~40 ~-1 black_concrete
