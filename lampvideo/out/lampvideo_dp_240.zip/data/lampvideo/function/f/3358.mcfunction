fill ~122 ~108 ~-1 ~122 ~108 ~-1 redstone_block
fill ~118 ~104 ~-1 ~118 ~104 ~-1 redstone_block
fill ~103 ~81 ~-1 ~103 ~81 ~-1 redstone_block
fill ~102 ~47 ~-1 ~102 ~47 ~-1 redstone_block
