fill ~125 ~167 ~-1 ~125 ~167 ~-1 redstone_block
fill ~96 ~160 ~-1 ~96 ~160 ~-1 redstone_block
fill ~148 ~119 ~-1 ~148 ~119 ~-1 redstone_block
fill ~149 ~118 ~-1 ~149 ~118 ~-1 black_concrete
