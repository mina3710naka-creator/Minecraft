fill ~58 ~200 ~-1 ~58 ~200 ~-1 black_concrete
fill ~60 ~199 ~-1 ~60 ~199 ~-1 black_concrete
