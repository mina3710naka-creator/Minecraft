fill ~166 ~93 ~-1 ~166 ~93 ~-1 redstone_block
fill ~230 ~74 ~-1 ~230 ~74 ~-1 redstone_block
fill ~232 ~73 ~-1 ~232 ~73 ~-1 redstone_block
fill ~230 ~90 ~-1 ~230 ~90 ~-1 black_concrete
fill ~232 ~81 ~-1 ~232 ~81 ~-1 black_concrete
fill ~230 ~69 ~-1 ~230 ~69 ~-1 black_concrete
fill ~174 ~62 ~-1 ~174 ~62 ~-1 black_concrete
fill ~177 ~5 ~-1 ~177 ~5 ~-1 black_concrete
