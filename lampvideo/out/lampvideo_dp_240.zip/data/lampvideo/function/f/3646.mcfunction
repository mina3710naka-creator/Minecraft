fill ~103 ~81 ~-1 ~103 ~81 ~-1 redstone_block
