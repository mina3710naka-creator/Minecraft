fill ~105 ~111 ~-1 ~105 ~111 ~-1 black_concrete
