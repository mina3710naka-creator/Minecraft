fill ~146 ~145 ~-1 ~146 ~145 ~-1 redstone_block
fill ~103 ~108 ~-1 ~103 ~108 ~-1 redstone_block
fill ~112 ~136 ~-1 ~112 ~136 ~-1 black_concrete
fill ~103 ~117 ~-1 ~103 ~117 ~-1 black_concrete
fill ~138 ~111 ~-1 ~138 ~111 ~-1 black_concrete
