fill ~231 ~89 ~-1 ~231 ~89 ~-1 redstone_block
fill ~235 ~83 ~-1 ~235 ~83 ~-1 redstone_block
