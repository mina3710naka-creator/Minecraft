fill ~111 ~52 ~-1 ~111 ~52 ~-1 redstone_block
fill ~124 ~45 ~-1 ~124 ~45 ~-1 black_concrete
