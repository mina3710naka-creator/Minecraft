fill ~175 ~141 ~-1 ~175 ~141 ~-1 redstone_block
fill ~103 ~84 ~-1 ~103 ~84 ~-1 redstone_block
fill ~120 ~78 ~-1 ~120 ~78 ~-1 redstone_block
fill ~98 ~76 ~-1 ~98 ~76 ~-1 redstone_block
fill ~102 ~67 ~-1 ~102 ~67 ~-1 redstone_block
fill ~200 ~220 ~-1 ~200 ~220 ~-1 black_concrete
fill ~117 ~134 ~-1 ~117 ~134 ~-1 black_concrete
