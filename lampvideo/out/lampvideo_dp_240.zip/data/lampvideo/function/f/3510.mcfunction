fill ~137 ~212 ~-1 ~137 ~212 ~-1 redstone_block
fill ~45 ~75 ~-1 ~45 ~75 ~-1 redstone_block
fill ~98 ~69 ~-1 ~98 ~69 ~-1 redstone_block
fill ~161 ~219 ~-1 ~161 ~219 ~-1 black_concrete
fill ~58 ~197 ~-1 ~58 ~197 ~-1 black_concrete
fill ~108 ~55 ~-1 ~108 ~55 ~-1 black_concrete
