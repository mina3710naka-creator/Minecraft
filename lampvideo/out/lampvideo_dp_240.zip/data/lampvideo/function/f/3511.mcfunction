fill ~211 ~81 ~-1 ~211 ~81 ~-1 redstone_block
fill ~112 ~57 ~-1 ~112 ~57 ~-1 redstone_block
fill ~116 ~53 ~-1 ~116 ~53 ~-1 redstone_block
fill ~115 ~52 ~-1 ~115 ~52 ~-1 redstone_block
