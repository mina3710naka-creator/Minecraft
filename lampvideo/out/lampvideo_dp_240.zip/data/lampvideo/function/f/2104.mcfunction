fill ~197 ~87 ~-1 ~197 ~87 ~-1 redstone_block
fill ~236 ~57 ~-1 ~236 ~57 ~-1 redstone_block
fill ~170 ~94 ~-1 ~170 ~94 ~-1 black_concrete
fill ~201 ~90 ~-1 ~201 ~90 ~-1 black_concrete
fill ~169 ~86 ~-1 ~169 ~86 ~-1 black_concrete
fill ~173 ~81 ~-1 ~173 ~81 ~-1 black_concrete
