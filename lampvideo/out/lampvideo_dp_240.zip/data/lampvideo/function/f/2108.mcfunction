fill ~169 ~120 ~-1 ~169 ~120 ~-1 redstone_block
fill ~172 ~96 ~-1 ~172 ~96 ~-1 black_concrete
