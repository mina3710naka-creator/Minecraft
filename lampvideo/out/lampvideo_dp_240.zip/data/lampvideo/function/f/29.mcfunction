fill ~59 ~149 ~-1 ~59 ~150 ~-1 redstone_block
fill ~156 ~133 ~-1 ~156 ~142 ~-1 redstone_block
fill ~90 ~88 ~-1 ~90 ~88 ~-1 redstone_block
fill ~152 ~87 ~-1 ~152 ~87 ~-1 redstone_block
fill ~114 ~83 ~-1 ~116 ~83 ~-1 redstone_block
fill ~66 ~145 ~-1 ~66 ~145 ~-1 black_concrete
fill ~155 ~82 ~-1 ~155 ~82 ~-1 black_concrete
