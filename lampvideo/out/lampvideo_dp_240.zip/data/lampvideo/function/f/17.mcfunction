fill ~87 ~155 ~-1 ~87 ~155 ~-1 redstone_block
fill ~85 ~156 ~-1 ~85 ~156 ~-1 black_concrete
fill ~119 ~145 ~-1 ~119 ~145 ~-1 black_concrete
fill ~156 ~85 ~-1 ~156 ~85 ~-1 black_concrete
