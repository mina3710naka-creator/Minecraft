fill ~228 ~90 ~-1 ~228 ~90 ~-1 redstone_block
fill ~224 ~88 ~-1 ~224 ~88 ~-1 redstone_block
fill ~233 ~81 ~-1 ~233 ~81 ~-1 redstone_block
fill ~221 ~96 ~-1 ~221 ~96 ~-1 black_concrete
fill ~220 ~94 ~-1 ~220 ~94 ~-1 black_concrete
