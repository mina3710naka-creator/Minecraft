fill ~119 ~126 ~-1 ~119 ~126 ~-1 redstone_block
fill ~119 ~122 ~-1 ~119 ~123 ~-1 redstone_block
fill ~122 ~122 ~-1 ~122 ~122 ~-1 redstone_block
fill ~117 ~117 ~-1 ~117 ~117 ~-1 redstone_block
fill ~118 ~114 ~-1 ~118 ~114 ~-1 redstone_block
fill ~120 ~110 ~-1 ~120 ~110 ~-1 redstone_block
