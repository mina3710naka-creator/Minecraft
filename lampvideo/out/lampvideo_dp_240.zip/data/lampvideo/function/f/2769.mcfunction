fill ~116 ~80 ~-1 ~116 ~80 ~-1 redstone_block
fill ~115 ~80 ~-1 ~115 ~80 ~-1 black_concrete
