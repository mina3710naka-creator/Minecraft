fill ~ ~0 ~-1 ~239 ~67 ~-1 black_concrete
fill ~ ~0 ~ ~239 ~67 ~ redstone_lamp[lit=false]
fill ~ ~68 ~-1 ~239 ~135 ~-1 black_concrete
fill ~ ~68 ~ ~239 ~135 ~ redstone_lamp[lit=false]
fill ~ ~136 ~-1 ~239 ~203 ~-1 black_concrete
fill ~ ~136 ~ ~239 ~203 ~ redstone_lamp[lit=false]
fill ~ ~204 ~-1 ~239 ~239 ~-1 black_concrete
fill ~ ~204 ~ ~239 ~239 ~ redstone_lamp[lit=false]
