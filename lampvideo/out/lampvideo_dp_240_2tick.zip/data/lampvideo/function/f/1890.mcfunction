fill ~228 ~90 ~-1 ~228 ~90 ~-1 black_concrete
fill ~228 ~90 ~ ~228 ~90 ~ redstone_lamp[lit=false]
fill ~224 ~88 ~-1 ~224 ~88 ~-1 black_concrete
fill ~224 ~88 ~ ~224 ~88 ~ redstone_lamp[lit=false]
fill ~233 ~81 ~-1 ~233 ~81 ~-1 black_concrete
fill ~233 ~81 ~ ~233 ~81 ~ redstone_lamp[lit=false]
fill ~221 ~96 ~-1 ~221 ~96 ~-1 redstone_block
fill ~220 ~94 ~-1 ~220 ~94 ~-1 redstone_block
