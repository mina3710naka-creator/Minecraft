fill ~121 ~105 ~-1 ~121 ~105 ~-1 redstone_block
fill ~105 ~50 ~-1 ~105 ~50 ~-1 redstone_block
