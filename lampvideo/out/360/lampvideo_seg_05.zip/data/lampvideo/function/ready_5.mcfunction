scoreboard players set #ready lv 5
