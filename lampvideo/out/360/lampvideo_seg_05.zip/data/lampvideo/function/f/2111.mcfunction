fill ~251 ~29 ~-1 ~251 ~29 ~-1 black_concrete
fill ~251 ~29 ~ ~251 ~29 ~ redstone_lamp[lit=false]
fill ~256 ~77 ~-1 ~256 ~77 ~-1 redstone_block
fill ~258 ~76 ~-1 ~258 ~76 ~-1 redstone_block
fill ~271 ~69 ~-1 ~271 ~69 ~-1 redstone_block
fill ~248 ~61 ~-1 ~248 ~61 ~-1 redstone_block
fill ~261 ~45 ~-1 ~261 ~45 ~-1 redstone_block
fill ~263 ~29 ~-1 ~263 ~29 ~-1 redstone_block
