fill ~334 ~149 ~-1 ~334 ~149 ~-1 black_concrete
fill ~334 ~149 ~ ~334 ~149 ~ redstone_lamp[lit=false]
fill ~346 ~120 ~-1 ~346 ~120 ~-1 redstone_block
fill ~328 ~116 ~-1 ~328 ~116 ~-1 redstone_block
fill ~356 ~109 ~-1 ~356 ~109 ~-1 redstone_block
