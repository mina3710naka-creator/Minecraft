fill ~341 ~119 ~-1 ~341 ~119 ~-1 black_concrete
fill ~341 ~119 ~ ~341 ~119 ~ redstone_lamp[lit=false]
