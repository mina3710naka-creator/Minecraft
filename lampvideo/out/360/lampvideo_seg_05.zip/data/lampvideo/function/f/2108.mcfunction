fill ~259 ~172 ~-1 ~259 ~172 ~-1 black_concrete
fill ~259 ~172 ~ ~259 ~172 ~ redstone_lamp[lit=false]
fill ~359 ~84 ~-1 ~359 ~84 ~-1 redstone_block
fill ~269 ~81 ~-1 ~269 ~81 ~-1 redstone_block
