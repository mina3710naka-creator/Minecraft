fill ~94 ~116 ~-1 ~94 ~116 ~-1 redstone_block
fill ~94 ~96 ~-1 ~94 ~96 ~-1 redstone_block
fill ~162 ~87 ~-1 ~162 ~87 ~-1 redstone_block
