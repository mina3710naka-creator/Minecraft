fill ~111 ~96 ~-1 ~111 ~96 ~-1 redstone_block
