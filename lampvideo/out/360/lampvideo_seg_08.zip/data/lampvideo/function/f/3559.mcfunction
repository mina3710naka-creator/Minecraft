fill ~264 ~178 ~-1 ~264 ~178 ~-1 black_concrete
fill ~264 ~178 ~ ~264 ~178 ~ redstone_lamp[lit=false]
fill ~315 ~124 ~-1 ~315 ~124 ~-1 black_concrete
fill ~315 ~124 ~ ~315 ~124 ~ redstone_lamp[lit=false]
fill ~314 ~123 ~-1 ~314 ~123 ~-1 black_concrete
fill ~314 ~123 ~ ~314 ~123 ~ redstone_lamp[lit=false]
fill ~358 ~0 ~-1 ~358 ~0 ~-1 black_concrete
fill ~358 ~0 ~ ~358 ~0 ~ redstone_lamp[lit=false]
