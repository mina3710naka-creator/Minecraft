fill ~211 ~314 ~-1 ~211 ~314 ~-1 black_concrete
fill ~211 ~314 ~ ~211 ~314 ~ redstone_lamp[lit=false]
fill ~279 ~199 ~-1 ~279 ~199 ~-1 black_concrete
fill ~279 ~199 ~ ~279 ~199 ~ redstone_lamp[lit=false]
fill ~211 ~315 ~-1 ~211 ~315 ~-1 redstone_block
fill ~272 ~196 ~-1 ~272 ~197 ~-1 redstone_block
fill ~332 ~117 ~-1 ~332 ~117 ~-1 redstone_block
fill ~331 ~116 ~-1 ~331 ~116 ~-1 redstone_block
