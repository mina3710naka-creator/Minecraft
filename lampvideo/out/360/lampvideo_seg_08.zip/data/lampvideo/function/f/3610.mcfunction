fill ~0 ~288 ~-1 ~359 ~323 ~-1 redstone_block
