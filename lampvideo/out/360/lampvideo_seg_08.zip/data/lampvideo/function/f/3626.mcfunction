fill ~210 ~144 ~-1 ~210 ~144 ~-1 redstone_block
fill ~151 ~97 ~-1 ~152 ~97 ~-1 redstone_block
fill ~147 ~96 ~-1 ~147 ~96 ~-1 redstone_block
fill ~157 ~72 ~-1 ~157 ~72 ~-1 redstone_block
