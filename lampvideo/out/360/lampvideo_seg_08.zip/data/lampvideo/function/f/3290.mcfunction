fill ~0 ~0 ~-1 ~359 ~35 ~-1 redstone_block
