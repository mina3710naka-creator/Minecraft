fill ~267 ~148 ~-1 ~267 ~148 ~-1 redstone_block
fill ~258 ~147 ~-1 ~258 ~147 ~-1 redstone_block
fill ~260 ~145 ~-1 ~260 ~146 ~-1 redstone_block
fill ~264 ~144 ~-1 ~264 ~145 ~-1 redstone_block
fill ~259 ~144 ~-1 ~259 ~144 ~-1 redstone_block
fill ~260 ~142 ~-1 ~260 ~142 ~-1 redstone_block
fill ~271 ~140 ~-1 ~271 ~140 ~-1 redstone_block
