fill ~0 ~144 ~-1 ~359 ~179 ~-1 redstone_block
