scoreboard players set #ready lv 8
