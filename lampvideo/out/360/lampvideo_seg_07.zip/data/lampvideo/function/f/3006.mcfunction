fill ~192 ~256 ~-1 ~192 ~256 ~-1 black_concrete
fill ~192 ~256 ~ ~192 ~256 ~ redstone_lamp[lit=false]
