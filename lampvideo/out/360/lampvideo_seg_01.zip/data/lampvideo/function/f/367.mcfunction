fill ~101 ~180 ~-1 ~101 ~180 ~-1 redstone_block
