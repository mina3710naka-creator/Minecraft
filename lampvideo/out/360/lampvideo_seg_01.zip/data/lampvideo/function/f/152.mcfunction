fill ~164 ~250 ~-1 ~164 ~250 ~-1 black_concrete
fill ~164 ~250 ~ ~164 ~250 ~ redstone_lamp[lit=false]
fill ~215 ~190 ~-1 ~215 ~190 ~-1 black_concrete
fill ~215 ~190 ~ ~215 ~190 ~ redstone_lamp[lit=false]
