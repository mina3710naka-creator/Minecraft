fill ~0 ~269 ~-1 ~359 ~359 ~-1 black_concrete
fill ~0 ~269 ~ ~359 ~359 ~ redstone_lamp[lit=false]
fill ~0 ~178 ~-1 ~359 ~268 ~-1 black_concrete
fill ~0 ~178 ~ ~359 ~268 ~ redstone_lamp[lit=false]
fill ~0 ~87 ~-1 ~359 ~177 ~-1 black_concrete
fill ~0 ~87 ~ ~359 ~177 ~ redstone_lamp[lit=false]
fill ~0 ~0 ~-1 ~359 ~86 ~-1 black_concrete
fill ~0 ~0 ~ ~359 ~86 ~ redstone_lamp[lit=false]
