fill ~251 ~297 ~-1 ~251 ~297 ~-1 redstone_block
