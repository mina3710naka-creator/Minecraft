fill ~0 ~288 ~-1 ~359 ~323 ~-1 black_concrete
fill ~0 ~288 ~ ~359 ~323 ~ redstone_lamp[lit=false]
