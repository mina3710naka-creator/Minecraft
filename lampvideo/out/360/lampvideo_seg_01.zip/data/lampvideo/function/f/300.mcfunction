fill ~0 ~324 ~-1 ~359 ~359 ~-1 black_concrete
fill ~0 ~324 ~ ~359 ~359 ~ redstone_lamp[lit=false]
