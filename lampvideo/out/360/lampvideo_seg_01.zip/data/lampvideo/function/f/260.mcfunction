fill ~0 ~108 ~-1 ~359 ~143 ~-1 black_concrete
fill ~0 ~108 ~ ~359 ~143 ~ redstone_lamp[lit=false]
