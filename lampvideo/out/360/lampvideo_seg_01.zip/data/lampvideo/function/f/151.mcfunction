fill ~141 ~223 ~-1 ~141 ~223 ~-1 black_concrete
fill ~141 ~223 ~ ~141 ~223 ~ redstone_lamp[lit=false]
fill ~139 ~195 ~-1 ~139 ~195 ~-1 black_concrete
fill ~139 ~195 ~ ~139 ~195 ~ redstone_lamp[lit=false]
fill ~221 ~194 ~-1 ~221 ~194 ~-1 black_concrete
fill ~221 ~194 ~ ~221 ~194 ~ redstone_lamp[lit=false]
fill ~197 ~200 ~-1 ~197 ~200 ~-1 redstone_block
fill ~220 ~192 ~-1 ~220 ~192 ~-1 redstone_block
