fill ~0 ~0 ~-1 ~359 ~35 ~-1 black_concrete
fill ~0 ~0 ~ ~359 ~35 ~ redstone_lamp[lit=false]
