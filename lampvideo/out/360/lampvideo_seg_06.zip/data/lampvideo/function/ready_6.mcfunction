scoreboard players set #ready lv 6
