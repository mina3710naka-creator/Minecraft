scoreboard players set #ready lv 9
