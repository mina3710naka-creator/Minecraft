fill ~341 ~112 ~-1 ~341 ~112 ~-1 redstone_block
fill ~275 ~80 ~-1 ~275 ~80 ~-1 redstone_block
