fill ~306 ~147 ~-1 ~306 ~147 ~-1 black_concrete
fill ~306 ~147 ~ ~306 ~147 ~ redstone_lamp[lit=false]
fill ~341 ~114 ~-1 ~341 ~114 ~-1 black_concrete
fill ~341 ~114 ~ ~341 ~114 ~ redstone_lamp[lit=false]
fill ~298 ~117 ~-1 ~298 ~117 ~-1 redstone_block
fill ~341 ~116 ~-1 ~341 ~116 ~-1 redstone_block
