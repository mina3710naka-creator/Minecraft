fill ~352 ~120 ~-1 ~352 ~120 ~-1 black_concrete
fill ~352 ~120 ~ ~352 ~120 ~ redstone_lamp[lit=false]
fill ~234 ~118 ~-1 ~234 ~118 ~-1 black_concrete
fill ~234 ~118 ~ ~234 ~118 ~ redstone_lamp[lit=false]
fill ~350 ~120 ~-1 ~350 ~120 ~-1 redstone_block
fill ~243 ~90 ~-1 ~243 ~90 ~-1 redstone_block
