fill ~273 ~196 ~-1 ~273 ~196 ~-1 redstone_block
