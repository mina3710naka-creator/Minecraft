fill ~143 ~188 ~-1 ~143 ~188 ~-1 redstone_block
fill ~157 ~174 ~-1 ~157 ~174 ~-1 redstone_block
fill ~149 ~169 ~-1 ~149 ~169 ~-1 redstone_block
