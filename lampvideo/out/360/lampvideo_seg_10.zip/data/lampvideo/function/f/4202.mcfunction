fill ~125 ~250 ~-1 ~125 ~250 ~-1 redstone_block
