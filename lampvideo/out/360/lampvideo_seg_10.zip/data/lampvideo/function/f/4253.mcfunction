fill ~124 ~22 ~-1 ~124 ~22 ~-1 redstone_block
