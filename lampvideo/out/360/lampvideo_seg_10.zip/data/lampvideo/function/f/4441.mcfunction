fill ~203 ~176 ~-1 ~203 ~176 ~-1 redstone_block
