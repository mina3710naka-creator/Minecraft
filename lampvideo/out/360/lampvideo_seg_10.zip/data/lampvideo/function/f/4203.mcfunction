fill ~215 ~165 ~-1 ~215 ~165 ~-1 black_concrete
fill ~215 ~165 ~ ~215 ~165 ~ redstone_lamp[lit=false]
