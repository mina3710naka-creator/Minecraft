fill ~0 ~144 ~-1 ~359 ~179 ~-1 black_concrete
fill ~0 ~144 ~ ~359 ~179 ~ redstone_lamp[lit=false]
