fill ~125 ~22 ~-1 ~125 ~22 ~-1 redstone_block
