fill ~0 ~216 ~-1 ~359 ~251 ~-1 black_concrete
fill ~0 ~216 ~ ~359 ~251 ~ redstone_lamp[lit=false]
