fill ~0 ~252 ~-1 ~359 ~287 ~-1 black_concrete
fill ~0 ~252 ~ ~359 ~287 ~ redstone_lamp[lit=false]
fill ~188 ~105 ~-1 ~188 ~105 ~-1 redstone_block
