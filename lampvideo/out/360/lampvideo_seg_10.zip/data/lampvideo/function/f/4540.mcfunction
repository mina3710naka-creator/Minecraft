fill ~0 ~180 ~-1 ~359 ~215 ~-1 black_concrete
fill ~0 ~180 ~ ~359 ~215 ~ redstone_lamp[lit=false]
