scoreboard players set #ready lv 10
