scoreboard objectives add lv dummy
execute unless score #run lv matches 1..2 run tellraw @a [{"text":"[ランプ動画] 読み込み完了 (360x360, 4584フレーム, 10区間)","color":"green"}]
