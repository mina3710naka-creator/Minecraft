scoreboard players set #run lv 0
schedule clear lampvideo:wait_off
schedule clear lampvideo:wait_on
stopsound @a * lampvideo:seg_01
stopsound @a * lampvideo:seg_02
stopsound @a * lampvideo:seg_03
stopsound @a * lampvideo:seg_04
stopsound @a * lampvideo:seg_05
stopsound @a * lampvideo:seg_06
stopsound @a * lampvideo:seg_07
stopsound @a * lampvideo:seg_08
stopsound @a * lampvideo:seg_09
stopsound @a * lampvideo:seg_10
