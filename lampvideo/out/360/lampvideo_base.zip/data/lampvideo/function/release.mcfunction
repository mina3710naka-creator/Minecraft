scoreboard players set #ready lv 0
function #lampvideo:ready
execute if score #ready lv matches 1 run datapack disable "file/lampvideo_seg_01.zip"
execute if score #ready lv matches 2 run datapack disable "file/lampvideo_seg_02.zip"
execute if score #ready lv matches 3 run datapack disable "file/lampvideo_seg_03.zip"
execute if score #ready lv matches 4 run datapack disable "file/lampvideo_seg_04.zip"
execute if score #ready lv matches 5 run datapack disable "file/lampvideo_seg_05.zip"
execute if score #ready lv matches 6 run datapack disable "file/lampvideo_seg_06.zip"
execute if score #ready lv matches 7 run datapack disable "file/lampvideo_seg_07.zip"
execute if score #ready lv matches 8 run datapack disable "file/lampvideo_seg_08.zip"
execute if score #ready lv matches 9 run datapack disable "file/lampvideo_seg_09.zip"
execute if score #ready lv matches 10 run datapack disable "file/lampvideo_seg_10.zip"
