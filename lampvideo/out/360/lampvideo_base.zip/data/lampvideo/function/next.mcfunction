execute if score #d lv matches 4584.. run function lampvideo:stop
execute if score #run lv matches 1 if score #c lv matches 0 if score #d lv matches 682 unless score #seg lv matches 2 run function lampvideo:switch
execute if score #run lv matches 1 if score #c lv matches 0 if score #d lv matches 1021 unless score #seg lv matches 3 run function lampvideo:switch
execute if score #run lv matches 1 if score #c lv matches 0 if score #d lv matches 1314 unless score #seg lv matches 4 run function lampvideo:switch
execute if score #run lv matches 1 if score #c lv matches 0 if score #d lv matches 2066 unless score #seg lv matches 5 run function lampvideo:switch
execute if score #run lv matches 1 if score #c lv matches 0 if score #d lv matches 2435 unless score #seg lv matches 6 run function lampvideo:switch
execute if score #run lv matches 1 if score #c lv matches 0 if score #d lv matches 2746 unless score #seg lv matches 7 run function lampvideo:switch
execute if score #run lv matches 1 if score #c lv matches 0 if score #d lv matches 3188 unless score #seg lv matches 8 run function lampvideo:switch
execute if score #run lv matches 1 if score #c lv matches 0 if score #d lv matches 3856 unless score #seg lv matches 9 run function lampvideo:switch
execute if score #run lv matches 1 if score #c lv matches 0 if score #d lv matches 4089 unless score #seg lv matches 10 run function lampvideo:switch
execute if score #run lv matches 1 if score #c lv matches 0 store result storage lampvideo:s n int 1 run scoreboard players get #d lv
execute if score #run lv matches 1 if score #c lv matches 0 run function lampvideo:step with storage lampvideo:s
execute if score #run lv matches 1 if score #c lv matches 0 run scoreboard players add #d lv 1
execute if score #run lv matches 1 run scoreboard players add #c lv 1
execute if score #run lv matches 1 if score #c lv matches 3.. run scoreboard players set #c lv 0
