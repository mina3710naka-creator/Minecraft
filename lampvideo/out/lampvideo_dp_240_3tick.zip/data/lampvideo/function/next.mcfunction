execute if score #d lv matches 4584.. run function lampvideo:stop
execute if score #run lv matches 1 if score #c lv matches 0 store result storage lampvideo:s n int 1 run scoreboard players get #d lv
execute if score #run lv matches 1 if score #c lv matches 0 run function lampvideo:step with storage lampvideo:s
execute if score #run lv matches 1 if score #c lv matches 0 run scoreboard players add #d lv 1
execute if score #run lv matches 1 run scoreboard players add #c lv 1
execute if score #run lv matches 1 if score #c lv matches 3.. run scoreboard players set #c lv 0
