fill ~ ~0 ~-1 ~239 ~44 ~1 air
fill ~ ~45 ~-1 ~239 ~89 ~1 air
fill ~ ~90 ~-1 ~239 ~134 ~1 air
fill ~ ~135 ~-1 ~239 ~179 ~1 air
fill ~ ~180 ~-1 ~239 ~224 ~1 air
fill ~ ~225 ~-1 ~239 ~239 ~1 air
forceload remove ~ ~-1 ~239 ~
