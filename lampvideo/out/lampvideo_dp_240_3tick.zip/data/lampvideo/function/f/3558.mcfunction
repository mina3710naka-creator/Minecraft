fill ~58 ~200 ~-1 ~58 ~200 ~-1 redstone_block
fill ~60 ~199 ~-1 ~60 ~199 ~-1 redstone_block
