fill ~0 ~24 ~-1 ~239 ~47 ~-1 redstone_block
