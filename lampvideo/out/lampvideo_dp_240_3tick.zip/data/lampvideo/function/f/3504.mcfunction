fill ~120 ~54 ~-1 ~120 ~54 ~-1 black_concrete
fill ~120 ~54 ~ ~120 ~54 ~ redstone_lamp[lit=false]
fill ~104 ~52 ~-1 ~104 ~52 ~-1 black_concrete
fill ~104 ~52 ~ ~104 ~52 ~ redstone_lamp[lit=false]
fill ~59 ~219 ~-1 ~59 ~219 ~-1 redstone_block
