fill ~103 ~85 ~-1 ~103 ~85 ~-1 redstone_block
