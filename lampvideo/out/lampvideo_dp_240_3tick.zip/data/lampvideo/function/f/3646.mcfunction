fill ~103 ~81 ~-1 ~103 ~81 ~-1 black_concrete
fill ~103 ~81 ~ ~103 ~81 ~ redstone_lamp[lit=false]
