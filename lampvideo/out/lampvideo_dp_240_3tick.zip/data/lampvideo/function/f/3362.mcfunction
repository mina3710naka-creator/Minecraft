fill ~111 ~52 ~-1 ~111 ~52 ~-1 black_concrete
fill ~111 ~52 ~ ~111 ~52 ~ redstone_lamp[lit=false]
fill ~124 ~45 ~-1 ~124 ~45 ~-1 redstone_block
