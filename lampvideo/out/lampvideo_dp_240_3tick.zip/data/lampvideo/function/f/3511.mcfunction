fill ~211 ~81 ~-1 ~211 ~81 ~-1 black_concrete
fill ~211 ~81 ~ ~211 ~81 ~ redstone_lamp[lit=false]
fill ~112 ~57 ~-1 ~112 ~57 ~-1 black_concrete
fill ~112 ~57 ~ ~112 ~57 ~ redstone_lamp[lit=false]
fill ~116 ~53 ~-1 ~116 ~53 ~-1 black_concrete
fill ~116 ~53 ~ ~116 ~53 ~ redstone_lamp[lit=false]
fill ~115 ~52 ~-1 ~115 ~52 ~-1 black_concrete
fill ~115 ~52 ~ ~115 ~52 ~ redstone_lamp[lit=false]
