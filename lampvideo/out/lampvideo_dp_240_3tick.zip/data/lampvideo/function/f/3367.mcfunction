fill ~102 ~50 ~-1 ~102 ~50 ~-1 redstone_block
