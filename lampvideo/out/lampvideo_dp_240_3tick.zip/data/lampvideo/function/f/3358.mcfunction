fill ~122 ~108 ~-1 ~122 ~108 ~-1 black_concrete
fill ~122 ~108 ~ ~122 ~108 ~ redstone_lamp[lit=false]
fill ~118 ~104 ~-1 ~118 ~104 ~-1 black_concrete
fill ~118 ~104 ~ ~118 ~104 ~ redstone_lamp[lit=false]
fill ~103 ~81 ~-1 ~103 ~81 ~-1 black_concrete
fill ~103 ~81 ~ ~103 ~81 ~ redstone_lamp[lit=false]
fill ~102 ~47 ~-1 ~102 ~47 ~-1 black_concrete
fill ~102 ~47 ~ ~102 ~47 ~ redstone_lamp[lit=false]
