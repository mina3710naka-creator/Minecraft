fill ~197 ~216 ~-1 ~197 ~216 ~-1 black_concrete
fill ~197 ~216 ~ ~197 ~216 ~ redstone_lamp[lit=false]
