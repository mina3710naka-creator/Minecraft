fill ~0 ~168 ~-1 ~239 ~191 ~-1 black_concrete
fill ~0 ~168 ~ ~239 ~191 ~ redstone_lamp[lit=false]
