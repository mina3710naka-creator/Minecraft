fill ~121 ~105 ~-1 ~121 ~105 ~-1 redstone_block
fill ~105 ~50 ~-1 ~105 ~50 ~-1 redstone_block
fill ~0 ~0 ~-1 ~239 ~23 ~-1 redstone_block
