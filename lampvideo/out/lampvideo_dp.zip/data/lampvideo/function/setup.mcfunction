kill @e[type=marker,tag=lampvideo]
summon marker ~ ~ ~ {Tags:["lampvideo"]}
fill ~ ~0 ~-1 ~179 ~90 ~-1 black_concrete
fill ~ ~0 ~ ~179 ~90 ~ redstone_lamp[lit=false]
fill ~ ~91 ~-1 ~179 ~179 ~-1 black_concrete
fill ~ ~91 ~ ~179 ~179 ~ redstone_lamp[lit=false]
tellraw @s [{"text":"[ランプ動画] 画面を設置しました。南側から北を向いて見てください。/function lampvideo:play で再生","color":"green"}]
