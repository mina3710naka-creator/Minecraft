fill ~176 ~55 ~-1 ~176 ~55 ~-1 black_concrete
fill ~180 ~52 ~-1 ~180 ~52 ~-1 black_concrete
