fill ~108 ~44 ~ ~108 ~44 ~ redstone_lamp[lit=false]
