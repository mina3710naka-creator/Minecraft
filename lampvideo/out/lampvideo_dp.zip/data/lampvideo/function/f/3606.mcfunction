fill ~112 ~62 ~-1 ~112 ~62 ~-1 black_concrete
