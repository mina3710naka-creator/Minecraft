fill ~112 ~58 ~-1 ~113 ~58 ~-1 black_concrete
fill ~107 ~57 ~-1 ~107 ~57 ~-1 black_concrete
