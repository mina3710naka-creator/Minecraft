fill ~104 ~113 ~ ~106 ~113 ~ redstone_lamp[lit=true]
fill ~111 ~112 ~ ~111 ~112 ~ redstone_lamp[lit=true]
