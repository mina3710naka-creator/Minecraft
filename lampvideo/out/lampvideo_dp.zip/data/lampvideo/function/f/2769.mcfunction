fill ~96 ~55 ~ ~96 ~55 ~ redstone_lamp[lit=true]
fill ~173 ~42 ~ ~173 ~42 ~ redstone_lamp[lit=false]
