fill ~147 ~129 ~-1 ~147 ~129 ~-1 redstone_block
fill ~139 ~121 ~-1 ~139 ~121 ~-1 redstone_block
fill ~139 ~88 ~-1 ~139 ~88 ~-1 redstone_block
fill ~113 ~69 ~-1 ~113 ~69 ~-1 redstone_block
fill ~98 ~161 ~-1 ~98 ~161 ~-1 black_concrete
fill ~148 ~118 ~-1 ~148 ~118 ~-1 black_concrete
