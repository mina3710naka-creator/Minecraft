fill ~77 ~67 ~ ~77 ~67 ~ redstone_lamp[lit=true]
fill ~75 ~65 ~ ~75 ~65 ~ redstone_lamp[lit=false]
fill ~74 ~62 ~ ~74 ~62 ~ redstone_lamp[lit=false]
