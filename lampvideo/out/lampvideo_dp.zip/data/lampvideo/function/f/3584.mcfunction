fill ~138 ~166 ~-1 ~139 ~166 ~-1 black_concrete
fill ~95 ~158 ~-1 ~95 ~158 ~-1 black_concrete
fill ~94 ~157 ~-1 ~94 ~157 ~-1 black_concrete
fill ~93 ~156 ~-1 ~93 ~156 ~-1 black_concrete
fill ~92 ~155 ~-1 ~92 ~155 ~-1 black_concrete
fill ~101 ~89 ~-1 ~101 ~89 ~-1 black_concrete
fill ~99 ~83 ~-1 ~99 ~83 ~-1 black_concrete
fill ~95 ~73 ~-1 ~95 ~73 ~-1 black_concrete
