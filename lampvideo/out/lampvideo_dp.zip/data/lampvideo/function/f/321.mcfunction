fill ~117 ~95 ~ ~117 ~95 ~ redstone_lamp[lit=false]
