fill ~96 ~44 ~-1 ~96 ~44 ~-1 redstone_block
fill ~131 ~142 ~-1 ~131 ~142 ~-1 black_concrete
