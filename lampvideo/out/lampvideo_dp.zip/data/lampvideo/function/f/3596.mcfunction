fill ~107 ~102 ~-1 ~107 ~102 ~-1 black_concrete
fill ~137 ~79 ~-1 ~137 ~79 ~-1 black_concrete
