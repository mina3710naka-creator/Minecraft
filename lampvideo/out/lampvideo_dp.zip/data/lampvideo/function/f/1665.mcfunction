fill ~87 ~146 ~-1 ~87 ~146 ~-1 redstone_block
