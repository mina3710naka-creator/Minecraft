fill ~122 ~147 ~-1 ~122 ~148 ~-1 redstone_block
fill ~134 ~139 ~-1 ~134 ~139 ~-1 redstone_block
fill ~102 ~83 ~-1 ~102 ~83 ~-1 redstone_block
fill ~96 ~79 ~-1 ~96 ~79 ~-1 redstone_block
fill ~92 ~68 ~-1 ~92 ~68 ~-1 redstone_block
fill ~102 ~87 ~-1 ~102 ~87 ~-1 black_concrete
