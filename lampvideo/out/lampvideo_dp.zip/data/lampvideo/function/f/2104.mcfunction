fill ~181 ~95 ~-1 ~181 ~95 ~-1 redstone_block
fill ~179 ~93 ~-1 ~179 ~93 ~-1 redstone_block
fill ~176 ~89 ~-1 ~177 ~89 ~-1 redstone_block
fill ~236 ~58 ~-1 ~236 ~58 ~-1 redstone_block
fill ~239 ~142 ~-1 ~239 ~142 ~-1 black_concrete
fill ~178 ~90 ~-1 ~178 ~90 ~-1 black_concrete
fill ~173 ~87 ~-1 ~173 ~87 ~-1 black_concrete
fill ~175 ~69 ~-1 ~175 ~69 ~-1 black_concrete
