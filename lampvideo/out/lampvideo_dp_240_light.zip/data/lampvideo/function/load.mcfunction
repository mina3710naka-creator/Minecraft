scoreboard objectives add lv dummy
scoreboard players set #run lv 0
tellraw @a [{"text":"[ランプ動画] 読み込み完了 (240x240, 2292フレーム)","color":"green"}]
