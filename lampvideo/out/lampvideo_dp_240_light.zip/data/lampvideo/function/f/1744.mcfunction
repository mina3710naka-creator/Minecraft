fill ~59 ~218 ~-1 ~60 ~218 ~-1 redstone_block
fill ~59 ~196 ~-1 ~59 ~196 ~-1 redstone_block
fill ~111 ~56 ~-1 ~111 ~56 ~-1 redstone_block
fill ~104 ~64 ~-1 ~104 ~64 ~-1 black_concrete
fill ~106 ~62 ~-1 ~106 ~62 ~-1 black_concrete
