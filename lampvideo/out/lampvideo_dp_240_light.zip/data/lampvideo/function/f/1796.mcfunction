fill ~62 ~77 ~-1 ~62 ~77 ~-1 black_concrete
fill ~139 ~63 ~-1 ~139 ~63 ~-1 black_concrete
