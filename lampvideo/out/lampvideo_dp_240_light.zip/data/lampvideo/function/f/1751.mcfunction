fill ~182 ~216 ~-1 ~182 ~216 ~-1 redstone_block
fill ~211 ~80 ~-1 ~211 ~80 ~-1 redstone_block
fill ~103 ~55 ~-1 ~103 ~55 ~-1 black_concrete
fill ~124 ~50 ~-1 ~124 ~50 ~-1 black_concrete
fill ~113 ~42 ~-1 ~113 ~42 ~-1 black_concrete
