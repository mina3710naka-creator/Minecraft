fill ~163 ~227 ~-1 ~163 ~227 ~-1 redstone_block
fill ~162 ~217 ~-1 ~162 ~217 ~-1 redstone_block
fill ~123 ~49 ~-1 ~123 ~49 ~-1 redstone_block
fill ~118 ~113 ~-1 ~118 ~113 ~-1 black_concrete
fill ~109 ~90 ~-1 ~109 ~90 ~-1 black_concrete
fill ~226 ~74 ~-1 ~226 ~74 ~-1 black_concrete
