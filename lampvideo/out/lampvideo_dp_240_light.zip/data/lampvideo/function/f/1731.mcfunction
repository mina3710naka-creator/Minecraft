fill ~162 ~224 ~-1 ~162 ~224 ~-1 redstone_block
fill ~58 ~200 ~-1 ~58 ~200 ~-1 redstone_block
fill ~101 ~58 ~-1 ~101 ~58 ~-1 redstone_block
fill ~114 ~56 ~-1 ~114 ~56 ~-1 redstone_block
fill ~200 ~219 ~-1 ~200 ~219 ~-1 black_concrete
fill ~202 ~137 ~-1 ~202 ~137 ~-1 black_concrete
fill ~105 ~70 ~-1 ~105 ~70 ~-1 black_concrete
fill ~98 ~55 ~-1 ~98 ~55 ~-1 black_concrete
