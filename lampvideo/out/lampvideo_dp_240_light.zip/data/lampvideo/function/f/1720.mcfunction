fill ~159 ~224 ~-1 ~159 ~224 ~-1 redstone_block
fill ~214 ~80 ~-1 ~214 ~80 ~-1 redstone_block
fill ~104 ~57 ~-1 ~104 ~57 ~-1 redstone_block
fill ~122 ~52 ~-1 ~122 ~52 ~-1 redstone_block
fill ~111 ~51 ~-1 ~111 ~51 ~-1 redstone_block
fill ~161 ~220 ~-1 ~161 ~220 ~-1 black_concrete
fill ~203 ~136 ~-1 ~203 ~136 ~-1 black_concrete
fill ~102 ~62 ~-1 ~102 ~62 ~-1 black_concrete
