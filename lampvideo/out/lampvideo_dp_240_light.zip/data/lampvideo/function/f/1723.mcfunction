fill ~79 ~224 ~-1 ~79 ~224 ~-1 redstone_block
fill ~179 ~218 ~-1 ~179 ~218 ~-1 redstone_block
fill ~189 ~133 ~-1 ~189 ~133 ~-1 redstone_block
fill ~43 ~73 ~-1 ~43 ~73 ~-1 redstone_block
fill ~119 ~41 ~-1 ~119 ~41 ~-1 black_concrete
