fill ~178 ~216 ~-1 ~178 ~216 ~-1 redstone_block
fill ~97 ~123 ~-1 ~97 ~123 ~-1 redstone_block
fill ~210 ~82 ~-1 ~210 ~82 ~-1 redstone_block
fill ~112 ~54 ~-1 ~112 ~54 ~-1 redstone_block
fill ~106 ~125 ~-1 ~106 ~125 ~-1 black_concrete
fill ~120 ~41 ~-1 ~121 ~41 ~-1 black_concrete
