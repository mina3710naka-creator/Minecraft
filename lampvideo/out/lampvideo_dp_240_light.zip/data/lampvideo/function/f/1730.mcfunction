fill ~79 ~223 ~-1 ~79 ~223 ~-1 redstone_block
fill ~109 ~96 ~-1 ~109 ~96 ~-1 redstone_block
fill ~121 ~53 ~-1 ~121 ~53 ~-1 redstone_block
fill ~111 ~100 ~-1 ~111 ~100 ~-1 black_concrete
