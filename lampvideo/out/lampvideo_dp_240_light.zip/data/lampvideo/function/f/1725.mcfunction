fill ~137 ~226 ~-1 ~137 ~226 ~-1 redstone_block
fill ~200 ~218 ~-1 ~200 ~218 ~-1 redstone_block
fill ~103 ~86 ~-1 ~103 ~86 ~-1 redstone_block
fill ~100 ~60 ~-1 ~100 ~60 ~-1 redstone_block
fill ~101 ~56 ~-1 ~101 ~56 ~-1 black_concrete
