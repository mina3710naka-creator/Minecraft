fill ~79 ~221 ~-1 ~79 ~221 ~-1 redstone_block
fill ~119 ~107 ~-1 ~119 ~107 ~-1 redstone_block
fill ~119 ~104 ~-1 ~119 ~104 ~-1 black_concrete
