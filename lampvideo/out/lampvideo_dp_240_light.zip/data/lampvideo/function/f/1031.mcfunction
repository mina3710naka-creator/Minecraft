fill ~156 ~81 ~-1 ~156 ~81 ~-1 redstone_block
fill ~238 ~79 ~-1 ~239 ~79 ~-1 redstone_block
fill ~193 ~26 ~-1 ~193 ~26 ~-1 black_concrete
