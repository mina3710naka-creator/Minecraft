fill ~108 ~59 ~-1 ~108 ~59 ~-1 redstone_block
fill ~119 ~55 ~-1 ~119 ~55 ~-1 redstone_block
fill ~0 ~0 ~-1 ~1 ~0 ~-1 redstone_block
fill ~180 ~142 ~-1 ~180 ~142 ~-1 black_concrete
fill ~107 ~83 ~-1 ~107 ~83 ~-1 black_concrete
fill ~220 ~77 ~-1 ~220 ~77 ~-1 black_concrete
fill ~107 ~62 ~-1 ~107 ~62 ~-1 black_concrete
