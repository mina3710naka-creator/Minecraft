fill ~159 ~223 ~-1 ~159 ~223 ~-1 redstone_block
fill ~201 ~216 ~-1 ~201 ~216 ~-1 redstone_block
fill ~186 ~133 ~-1 ~186 ~133 ~-1 redstone_block
fill ~124 ~52 ~-1 ~124 ~52 ~-1 redstone_block
fill ~138 ~205 ~-1 ~138 ~205 ~-1 black_concrete
fill ~112 ~42 ~-1 ~112 ~42 ~-1 black_concrete
