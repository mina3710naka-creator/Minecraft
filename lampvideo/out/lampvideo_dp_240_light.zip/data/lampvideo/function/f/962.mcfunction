fill ~228 ~90 ~-1 ~228 ~90 ~-1 redstone_block
fill ~233 ~81 ~-1 ~233 ~81 ~-1 redstone_block
fill ~231 ~75 ~-1 ~231 ~75 ~-1 redstone_block
fill ~136 ~141 ~-1 ~136 ~141 ~-1 black_concrete
fill ~229 ~75 ~-1 ~229 ~75 ~-1 black_concrete
fill ~184 ~60 ~-1 ~184 ~60 ~-1 black_concrete
