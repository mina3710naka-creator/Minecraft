fill ~175 ~131 ~-1 ~175 ~131 ~-1 redstone_block
fill ~214 ~81 ~-1 ~214 ~81 ~-1 redstone_block
fill ~104 ~75 ~-1 ~104 ~75 ~-1 redstone_block
fill ~111 ~55 ~-1 ~111 ~55 ~-1 redstone_block
fill ~222 ~76 ~-1 ~222 ~76 ~-1 black_concrete
