fill ~202 ~217 ~-1 ~202 ~217 ~-1 redstone_block
fill ~189 ~119 ~-1 ~189 ~119 ~-1 redstone_block
fill ~183 ~118 ~-1 ~183 ~118 ~-1 redstone_block
fill ~216 ~81 ~-1 ~216 ~81 ~-1 redstone_block
fill ~110 ~50 ~-1 ~110 ~50 ~-1 redstone_block
fill ~109 ~59 ~-1 ~109 ~59 ~-1 black_concrete
